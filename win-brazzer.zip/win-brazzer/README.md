# WIN BRAZZER (demo points only)
Free-to-play prediction games with virtual points. No deposits, withdrawals, or cash value.

## Setup
1. Create a Supabase project (free tier).
2. SQL Editor → run `supabase/migrations/001_init.sql`.
3. Database → Extensions → enable `pg_cron`, then run:
   `select cron.schedule('win-brazzer-tick','5 seconds','select tick()');` (second-level schedules need pg_cron 1.5+; otherwise use `'* * * * *'`).
3b. Run `supabase/migrations/002_admin.sql` too (admin tools, game schedule).
3c. Run `supabase/migrations/003_wallet.sql` (simulated TEST MODE wallet).
3d. Run `supabase/migrations/004_fair_results.sql` (fair seeded results, result audit, admin round statistics).
4. First admin (server-side only, via SQL Editor after that user signs up):
   `update profiles set role='admin' where id = '<user uuid>';`
   Users cannot change `role`: clients have no UPDATE rights beyond `display_name`.
5. Frontend env (`.env`): `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
   Never put the service-role key in frontend code.

## Security model
- All balance changes happen in `ledger_add` (immutable ledger, unique idempotency key, `balance >= 0`).
- Clients only SELECT own rows (RLS); writes use RPCs: `claim_daily_reward`, `place_prediction`.
- Results come from `settle_round` and never read the predictions table.
- Admin actions go through `admin_*` RPCs, check `is_admin()` in the DB, and write to `admin_audit_logs`.
- Rate limiting: add at the Supabase API gateway / edge layer (not included yet).

## Game rules (show these in the UI)
- Number: pick 0-9, exact match pays 9x entry. Color: green/red 1.9x (45% each), violet 4x (10%).
- Entry 10-500 points, one prediction per round.

## Run the frontend
```
cp .env.example .env   # fill in Supabase URL + anon key
npm install
npm run dev
```
Deploy: push to GitHub, import in Vercel or Netlify (free tier), set the two `VITE_` env vars, then add your custom domain under Domains and create the DNS record they show.
In Supabase → Authentication → URL Configuration, set Site URL to your domain (needed for password reset and email confirmation).

## Admin dashboard
Open `/#/admin` (link in the landing page footer). Only accounts with `role='admin'` get in; every action is checked again inside the database.

## Simulated wallet (TEST MODE)
- Wallet page: balance, Deposit (test), Withdraw (test), requests with status and time, all labeled TEST MODE.
- Deposits credit test points only through the `test_deposit` function (server-validated, idempotent key, 10,000 per request, 50,000 per day).
- Withdrawals: `request_withdrawal` holds the points at once, one pending request per user. An admin approves or rejects in the admin dashboard; rejection refunds. Admins cannot review their own requests. Every review is written to the audit log.
- No payment gateway, bank, UPI or card data exists anywhere. Test points have no cash value and must never be paid out in money.

## Fair results and admin statistics
- When a round opens, the server creates a secret random seed and publishes only its hash (`game_rounds.seed_hash`).
- When it closes, the result is computed from that seed alone, saved in `game_results` with a timestamp, and written once to `result_audit` (unique per round, immutable). Entries are locked because the round turns `settled`.
- Bets are never read while computing the result.
- The admin dashboard shows total points and player counts for every number and colour in the current round. This is a read-only function (`admin_round_stats`) that the result code never calls.

### Testing
1. Run all four migrations, start `tick()` with pg_cron, and create an admin (README steps above).
2. Sign in as two users and place different bets (different numbers, colours and amounts) in the same round.
3. In the admin dashboard press Refresh and check the totals and player counts per option.
4. After the round closes, confirm a row appears in Result history and in `result_audit`.
5. Verify a finished round in the SQL editor:
   `select encode(digest(decode(seed_hex,'hex'),'sha256'),'hex') = (select seed_hash from game_rounds where id = round_id) as seed_matches from game_results order by settled_at desc limit 5;`
6. Try to cheat: call `select settle_round('<finished round id>')` again. Nothing changes, and `update game_results ...` fails (immutable).
