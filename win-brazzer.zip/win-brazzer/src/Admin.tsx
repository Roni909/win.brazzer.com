import { useCallback, useEffect, useState } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase, configured } from './supabase'
type Row = Record<string, any>

function csv(name: string, rows: Row[]) {
  if (!rows.length) return
  const keys = Object.keys(rows[0])
  const esc = (v: any) => { let s = String(v ?? ''); if (/^[=+\-@]/.test(s)) s = "'" + s; return `"${s.replace(/"/g, '""')}"` }
  const text = [keys.join(','), ...rows.map(r => keys.map(k => esc(r[k])).join(','))].join('\n')
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv' })); a.download = name + '.csv'; a.click()
}

function Panel() {
  const [stats, setStats] = useState<Row>({}), [q, setQ] = useState(''), [users, setUsers] = useState<Row[]>([]), [sel, setSel] = useState<Row | null>(null)
  const [tx, setTx] = useState<Row[]>([]), [pr, setPr] = useState<Row[]>([]), [audit, setAudit] = useState<Row[]>([]), [gs, setGs] = useState<Row[]>([]), [wr, setWr] = useState<Row[]>([]), [st, setSt] = useState<Row[]>([]), [ra, setRa] = useState<Row[]>([])
  const [title, setTitle] = useState(''), [body, setBody] = useState(''), [msg, setMsg] = useState('')
  const loadUsers = useCallback(async () => {
    const clean = q.replace(/[^A-Za-z0-9]/g, '')
    const r = await supabase.from('profiles').select('*').ilike('user_code', `%${clean}%`).order('created_at', { ascending: false }).limit(50)
    setUsers(r.data ?? [])
  }, [q])
  const loadMisc = useCallback(async () => {
    const s = await supabase.rpc('admin_stats'); setStats(s.data ?? {})
    setSt((await supabase.rpc('admin_round_stats')).data ?? [])
    setRa((await supabase.from('result_audit').select('*').order('generated_at', { ascending: false }).limit(20)).data ?? [])
    setAudit((await supabase.from('admin_audit_logs').select('*').order('created_at', { ascending: false }).limit(15)).data ?? [])
    setGs((await supabase.from('game_settings').select('*')).data ?? [])
    setWr((await supabase.from('wallet_requests').select('*').order('created_at', { ascending: false }).limit(30)).data ?? [])
  }, [])
  useEffect(() => { loadUsers() }, [loadUsers]); useEffect(() => { loadMisc() }, [loadMisc])
  async function pick(u: Row) {
    setSel(u)
    setTx((await supabase.from('virtual_point_transactions').select('*').eq('user_id', u.id).order('created_at', { ascending: false }).limit(30)).data ?? [])
    setPr((await supabase.from('game_predictions').select('*, game_rounds(game,period,result)').eq('user_id', u.id).order('created_at', { ascending: false }).limit(30)).data ?? [])
  }
  const run = async (p: PromiseLike<{ error: any }>, ok: string) => { const { error } = await p; setMsg(error ? error.message : ok); loadUsers(); loadMisc(); if (sel) pick(sel) }
  const toggle = (u: Row) => run(supabase.rpc('admin_set_status', { target: u.id, new_status: u.status === 'active' ? 'suspended' : 'active' }), 'Status updated')
  const grant = (u: Row) => { const a = Number(prompt('Points to add (negative to remove):')); if (!a) return; run(supabase.rpc('admin_grant_points', { target: u.id, amt: a, note: prompt('Note:') || '' }), 'Points updated') }
  async function exportAll(t: 'profiles' | 'virtual_point_transactions') { csv(t, (await supabase.from(t).select('*').order('created_at', { ascending: false }).limit(5000)).data ?? []) }
  return <>
    <div className="card"><h3>Statistics</h3><table><tbody>{Object.entries(stats).map(([k, v]) => <tr key={k}><td>{k.replace(/_/g, ' ')}</td><td>{String(v)}</td></tr>)}</tbody></table>
      <div className="row" style={{ marginTop: 8 }}><button className="ghost" onClick={() => exportAll('profiles')}>Export users CSV</button><button className="ghost" onClick={() => exportAll('virtual_point_transactions')}>Export transactions CSV</button></div><p className="ok">{msg}</p></div>
    <div className="card"><h3>Users</h3><input placeholder="Search by user ID" value={q} onChange={e => setQ(e.target.value)} />
      <table><tbody>{users.map(u => <tr key={u.id}><td onClick={() => pick(u)} style={{ cursor: 'pointer' }}><b>{u.user_code}</b><br /><span className="mut">{u.display_name} · {u.role}</span></td><td>{u.status}</td>
        <td><button className="ghost" onClick={() => toggle(u)}>{u.status === 'active' ? 'Suspend' : 'Reactivate'}</button> <button className="ghost" onClick={() => grant(u)}>Points</button></td></tr>)}</tbody></table></div>
    {sel && <div className="card"><h3>{sel.user_code}: history</h3><table><tbody>{tx.map(t => <tr key={t.id}><td>{t.kind}</td><td>{t.amount}</td></tr>)}</tbody></table><hr />
      <table><tbody>{pr.map(p => <tr key={p.id}><td>{p.game_rounds.game} {p.game_rounds.period}</td><td>pick {p.choice}</td><td>{p.points}</td><td>+{p.payout ?? 0}</td></tr>)}</tbody></table></div>}
    <div className="card"><h3>Withdrawal requests (TEST MODE)</h3><table><tbody>{wr.filter(w => w.kind === 'withdrawal').map(w => <tr key={w.id}><td>{w.amount}</td><td>{w.status}</td><td className="mut">{new Date(w.created_at).toLocaleString()}</td>
      <td>{w.status === 'pending' && <><button className="sm" onClick={() => run(supabase.rpc('admin_review_withdrawal', { p_id: w.id, p_approve: true }), 'Approved')}>Approve</button> <button className="ghost sm" onClick={() => run(supabase.rpc('admin_review_withdrawal', { p_id: w.id, p_approve: false }), 'Rejected, points refunded')}>Reject</button></>}</td></tr>)}</tbody></table></div>
    <div className="card"><h3>All wallet transactions (TEST MODE)</h3><table><tbody>{wr.map(w => <tr key={w.id}><td>{w.kind}</td><td>{w.amount}</td><td>{w.status}</td><td className="mut">{new Date(w.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>
    <div className="card"><div className="row"><h3>Round statistics (view only)</h3><button className="ghost sm" onClick={loadMisc}>Refresh</button></div>
      <p className="mut">Totals for the current open round. Results are drawn from a secret random seed and never use these numbers.</p>
      {(['number', 'color'] as const).map(g => {
        const opts: [number, string][] = g === 'number' ? [...Array(10).keys()].map(n => [n, String(n)] as [number, string]) : [[0, 'Green'], [1, 'Red'], [2, 'Violet']]
        return <div key={g}><b>{g}</b> <span className="mut">{st.find(x => x.game === g)?.period ?? 'no bets yet'}</span>
          <table><tbody>{opts.map(([c, l]) => { const x = st.find(y => y.game === g && y.choice === c); return <tr key={c}><td>{l}</td><td>{x?.points ?? 0} pts</td><td>{x?.players ?? 0} players</td></tr> })}</tbody></table></div>
      })}</div>
    <div className="card"><h3>Result history (server-generated)</h3><table><tbody>{ra.map(a => <tr key={a.id}><td>{a.game}</td><td>{a.result}</td><td className="mut">{new Date(a.generated_at).toLocaleString()}</td></tr>)}</tbody></table></div>
    <div className="card"><h3>Announcement</h3><input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} /><input placeholder="Message" value={body} onChange={e => setBody(e.target.value)} />
      <button onClick={() => run(supabase.rpc('admin_post_announcement', { p_title: title, p_body: body }), 'Posted').then(() => { setTitle(''); setBody('') })}>Post to all users</button></div>
    <div className="card"><h3>Game schedule</h3>{gs.map(g => <div className="row" key={g.game}><span>{g.game}</span>
      <button className="ghost" onClick={() => { const s = Number(prompt('Round length in seconds (15-3600):', g.round_seconds)); if (s) run(supabase.rpc('admin_set_game_settings', { p_game: g.game, p_seconds: s, p_enabled: g.enabled }), 'Saved') }}>{g.round_seconds}s</button>
      <button className="ghost" onClick={() => run(supabase.rpc('admin_set_game_settings', { p_game: g.game, p_seconds: g.round_seconds, p_enabled: !g.enabled }), 'Saved')}>{g.enabled ? 'Enabled' : 'Disabled'}</button></div>)}</div>
    <div className="card"><h3>Audit log</h3><table><tbody>{audit.map(a => <tr key={a.id}><td>{a.action}</td><td className="mut">{new Date(a.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>
  </>
}

export default function Admin() {
  const [session, setSession] = useState<Session | null>(null), [ok, setOk] = useState<boolean | null>(null)
  const [email, setEmail] = useState(''), [pw, setPw] = useState(''), [err, setErr] = useState('')
  useEffect(() => {
    if (!configured) return
    supabase.auth.getSession().then(r => setSession(r.data.session))
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s)); return () => data.subscription.unsubscribe()
  }, [])
  useEffect(() => { if (session) supabase.rpc('is_admin').then(r => setOk(Boolean(r.data))); else setOk(null) }, [session])
  if (!configured) return <div className="wrap"><div className="card">Set your Supabase keys in .env (see README).</div></div>
  const leave = () => { location.hash = ''; location.reload() }
  return <div className="wrap"><div className="row"><div className="logo">ADMIN</div><button className="ghost" onClick={leave}>Site</button></div>
    {!session ? <div className="card"><h3>Admin login</h3><input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} /><input placeholder="Password" type="password" value={pw} onChange={e => setPw(e.target.value)} />
      <p className="err">{err}</p><button onClick={async () => { const { error } = await supabase.auth.signInWithPassword({ email, password: pw }); setErr(error?.message ?? '') }}>Login</button></div>
      : ok === null ? <p>Checking…</p>
      : !ok ? <div className="card"><p className="err">This account is not an administrator.</p><button className="ghost" onClick={() => supabase.auth.signOut()}>Log out</button></div>
      : <><Panel /><button className="ghost" onClick={() => supabase.auth.signOut()}>Log out</button></>}
  </div>
}
