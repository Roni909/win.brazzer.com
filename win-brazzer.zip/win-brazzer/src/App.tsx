import { useCallback, useEffect, useState } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase, configured } from './supabase'
import Landing from './Landing'
import Admin from './Admin'
import { Notifications, GameHistory, StaticPage } from './Pages'

type Row = Record<string, any>
const COLORS = ['green', 'red', 'violet']
const label = (g: string, n: number) => (g === 'number' ? String(n) : COLORS[n])

function Auth({ initial, onBack }: { initial: 'in' | 'up'; onBack: () => void }) {
  const ref = new URLSearchParams(location.search).get('ref') || ''
  const [mode, setMode] = useState<'in' | 'up' | 'reset'>(ref ? 'up' : initial)
  const [email, setEmail] = useState(''), [pw, setPw] = useState(''), [code, setCode] = useState(ref)
  const [msg, setMsg] = useState(''), [busy, setBusy] = useState(false)
  async function go() {
    setBusy(true); setMsg('')
    let error
    if (mode === 'in') ({ error } = await supabase.auth.signInWithPassword({ email, password: pw }))
    else if (mode === 'up') {
      const r = await supabase.auth.signUp({ email, password: pw, options: { data: { ref: code || null } } })
      error = r.error; if (!error && !r.data.session) setMsg('Check your email to confirm your account.')
    } else {
      ({ error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: location.origin }))
      if (!error) setMsg('Password reset email sent.')
    }
    if (error) setMsg(error.message)
    setBusy(false)
  }
  return (
    <div className="wrap">
      <div className="logo">WIN BRAZZER</div>
      <p><a href="#" onClick={e => { e.preventDefault(); onBack() }}>← Back</a></p>
      <p className="mut">Free-to-play prediction games. Demo points only: no deposits, no withdrawals, no cash value.</p>
      <div className="card">
        <h2>{mode === 'in' ? 'Login' : mode === 'up' ? 'Create account' : 'Reset password'}</h2>
        <input placeholder="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} />
        {mode !== 'reset' && <input placeholder="Password (min 8)" type="password" value={pw} onChange={e => setPw(e.target.value)} />}
        {mode === 'up' && <input placeholder="Referral code (optional)" value={code} onChange={e => setCode(e.target.value)} />}
        <p className={msg.startsWith('Check') || msg.includes('sent') ? 'ok' : 'err'}>{msg}</p>
        <button disabled={busy || !email || (mode !== 'reset' && pw.length < 8)} onClick={go}>{busy ? 'Please wait…' : 'Continue'}</button>
        <p className="mut">
          <a href="#" onClick={e => { e.preventDefault(); setMode(mode === 'in' ? 'up' : 'in') }}>{mode === 'in' ? 'New here? Register' : 'Have an account? Login'}</a>
          {' · '}<a href="#" onClick={e => { e.preventDefault(); setMode('reset') }}>Forgot password</a>
        </p>
      </div>
    </div>
  )
}

function Game({ kind, me, refresh }: { kind: 'number' | 'color'; me: Row; refresh: () => void }) {
  const [round, setRound] = useState<Row | null>(null), [past, setPast] = useState<Row[]>([]), [mine, setMine] = useState<Row[]>([])
  const [choice, setChoice] = useState<number | null>(null), [pts, setPts] = useState(10), [msg, setMsg] = useState(''), [now, setNow] = useState(Date.now())
  const load = useCallback(async () => {
    const r = await supabase.from('game_rounds').select('*').eq('game', kind).eq('status', 'open').order('ends_at').limit(1)
    setRound(r.data?.[0] ?? null)
    const p = await supabase.from('game_rounds').select('*').eq('game', kind).eq('status', 'settled').order('ends_at', { ascending: false }).limit(10)
    setPast(p.data ?? [])
    const m = await supabase.from('game_predictions').select('*, game_rounds!inner(game,period,result)').eq('game_rounds.game', kind).order('created_at', { ascending: false }).limit(10)
    setMine(m.data ?? []); refresh()
  }, [kind, refresh])
  useEffect(() => { load(); const a = setInterval(load, 3000), b = setInterval(() => setNow(Date.now()), 250); return () => { clearInterval(a); clearInterval(b) } }, [load])
  const left = round ? Math.max(0, Math.ceil((new Date(round.ends_at).getTime() - now) / 1000)) : 0
  const entered = round && mine.some(m => m.round_id === round.id)
  async function submit() {
    if (!round || choice === null) return
    const { error } = await supabase.rpc('place_prediction', { p_round: round.id, p_choice: choice, p_points: pts })
    setMsg(error ? error.message : 'Prediction submitted!'); load()
  }
  const last = past[0], lastMine = last && mine.find(m => m.round_id === last.id)
  return (
    <>
      <div className="card">
        <h2>{kind === 'number' ? 'Number Prediction' : 'Color Prediction'}</h2>
        <p className="mut">Rules: pick {kind === 'number' ? '0-9; exact match pays 9× your entry' : 'green/red (45% each, 1.9×) or violet (10%, 4×)'}. Entry 10-500 demo points, one prediction per round. Results are random on the server and never depend on player picks. Points have no cash value.</p>
        {round ? <>
          <div className="mut">Round {round.period}</div><div className="timer">{left}s</div>
          <div className={'grid' + (kind === 'color' ? ' grid3' : '')}>
            {(kind === 'number' ? [...Array(10).keys()] : [0, 1, 2]).map(n =>
              <button key={n} className={`opt ${kind === 'color' ? COLORS[n] : ''} ${choice === n ? 'sel' : ''}`} onClick={() => setChoice(n)}>{label(kind, n)}</button>)}
          </div>
          <div className="row" style={{ marginTop: 10 }}>
            <input type="number" min={10} max={500} step={10} value={pts} onChange={e => setPts(Number(e.target.value))} />
            <button disabled={entered || left === 0 || choice === null || pts < 10 || pts > 500 || me.status !== 'active'} onClick={submit}>{entered ? 'Submitted' : 'Submit'}</button>
          </div>
          <p className={msg.startsWith('Pred') ? 'ok' : 'err'}>{msg}</p>
        </> : <p className="err">No active round. Make sure the pg_cron tick job is scheduled (see README).</p>}
      </div>
      {last && <div className="card pop">Last result ({last.period}): <b>{label(kind, last.result)}</b>{lastMine ? (lastMine.payout > 0 ? ` 🎉 You won ${lastMine.payout}` : ' – no win') : ''}</div>}
      <div className="card"><h3>Previous results</h3>{past.map(p => <span key={p.id} style={{ marginRight: 8 }}>{label(kind, p.result)}</span>)}</div>
      <div className="card"><h3>My predictions</h3><table><tbody>{mine.map(m =>
        <tr key={m.id}><td>{m.game_rounds.period}</td><td>{label(kind, m.choice)}</td><td>{m.points}</td><td>{m.game_rounds.result === null ? 'pending' : `→ ${label(kind, m.game_rounds.result)} (+${m.payout ?? 0})`}</td></tr>)}</tbody></table></div>
    </>
  )
}

function Txns() {
  const [rows, setRows] = useState<Row[]>([])
  useEffect(() => { supabase.from('virtual_point_transactions').select('*').order('created_at', { ascending: false }).limit(50).then(r => setRows(r.data ?? [])) }, [])
  return <div className="card"><h3>Transaction history</h3><table><tbody>{rows.map(r => <tr key={r.id}><td>{r.kind}</td><td>{r.amount > 0 ? '+' : ''}{r.amount}</td><td className="mut">{new Date(r.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>
}

function Home({ me, bal, stats, refresh, go }: { me: Row; bal: number; stats: Row; refresh: () => void; go: (t: string) => void }) {
  const [notes, setNotes] = useState<Row[]>([])
  useEffect(() => { supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(5).then(r => setNotes(r.data ?? [])) }, [])
  return <>
    <div className="card"><div className="mut">Demo points (no cash value)</div><div className="big">{bal.toLocaleString()}</div>
      <div className="mut">ID {me.user_code} · played {stats.played} · won {stats.won}</div><div className="row" style={{ marginTop: 8 }}><button onClick={() => go('wallet')}>Deposit (test)</button><button className="ghost" onClick={() => go('wallet')}>Withdraw (test)</button></div></div>
    <div className="card"><h3>Games</h3><div className="row"><button onClick={() => go('number')}>Number</button><button onClick={() => go('color')}>Color</button><button className="ghost" onClick={() => go('rewards')}>Daily reward</button></div></div>
    <GameHistory limit={5} />
    <div className="card"><h3>Notifications</h3>{notes.length ? notes.map(n => <p key={n.id}><b>{n.title}</b><br /><span className="mut">{n.body}</span></p>) : <p className="mut">Nothing new.</p>}</div>
  </>
}

function Rewards({ refresh }: { refresh: () => void }) {
  const [msg, setMsg] = useState('')
  async function claim() {
    const { data, error } = await supabase.rpc('claim_daily_reward')
    setMsg(error ? error.message : data ? '+100 points claimed!' : 'Already claimed today.'); refresh()
  }
  return <><div className="card"><h3>Daily reward</h3><p className="mut">100 free demo points every day.</p><button onClick={claim}>Claim</button><p>{msg}</p></div><Txns /></>
}

function Invite({ me }: { me: Row }) {
  const [code, setCode] = useState(''), [ev, setEv] = useState<Row[]>([])
  useEffect(() => {
    supabase.from('referral_codes').select('code').maybeSingle().then(r => setCode(r.data?.code ?? ''))
    supabase.from('referral_events').select('*').eq('referrer_id', me.id).then(r => setEv(r.data ?? []))
  }, [me.id])
  const link = `${location.origin}/?ref=${code}`
  return <><div className="card"><h3>Invite friends</h3><p className="mut">You and your friend each get 200 free demo points when they register with your code. One reward per new account; self-referrals are rejected.</p>
    <div className="big">{code}</div><p className="mut">{link}</p>
    <button onClick={() => navigator.clipboard?.writeText(link)}>Copy link</button></div>
    <div className="card"><h3>Referral history ({ev.length})</h3><table><tbody>{ev.map(e => <tr key={e.id}><td>Registered {new Date(e.created_at).toLocaleDateString()}</td><td>+{e.reward} paid</td></tr>)}</tbody></table></div></>
}

function Account({ me, reload, go }: { me: Row; reload: () => void; go: (t: string) => void }) {
  const [name, setName] = useState(me.display_name || ''), [msg, setMsg] = useState('')
  async function save() { const { error } = await supabase.from('profiles').update({ display_name: name }).eq('id', me.id); setMsg(error ? error.message : 'Saved'); reload() }
  const more: [string, string][] = [['wallet', 'Wallet'], ['notifications', 'Notifications'], ['history', 'Game history'], ['txns', 'Transactions'], ['help', 'Help'], ['terms', 'Terms'], ['privacy', 'Privacy']]
  return <>
    <div className="card"><h3>Profile</h3><p className="mut">ID {me.user_code} · status {me.status} · joined {new Date(me.created_at).toLocaleDateString()}</p>
      <input value={name} maxLength={40} onChange={e => setName(e.target.value)} /><div className="row"><button onClick={save}>Save</button><button className="ghost" onClick={() => supabase.auth.signOut()}>Log out</button></div><p className="ok">{msg}</p></div>
    <div className="card"><h3>More</h3><div className="row" style={{ flexWrap: 'wrap' }}>{more.map(([k, t]) => <button key={k} className="ghost" onClick={() => go(k)}>{t}</button>)}</div></div>
  </>
}

function Wallet({ bal, refresh }: { bal: number; refresh: () => void }) {
  const [amt, setAmt] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false), [key, setKey] = useState(() => crypto.randomUUID())
  const [rows, setRows] = useState<Row[]>([]), [tx, setTx] = useState<Row[]>([])
  const load = useCallback(async () => {
    setRows((await supabase.from('wallet_requests').select('*').order('created_at', { ascending: false }).limit(30)).data ?? [])
    setTx((await supabase.from('virtual_point_transactions').select('*').order('created_at', { ascending: false }).limit(30)).data ?? [])
    refresh()
  }, [refresh])
  useEffect(() => { load() }, [load])
  async function act(fn: 'test_deposit' | 'request_withdrawal') {
    const a = Math.floor(Number(amt)); if (!(a >= 1)) return setMsg('Enter a test amount.')
    setBusy(true)
    const { error } = await supabase.rpc(fn, { p_amount: a, p_key: key })   // server validates; browser never sends a balance
    setMsg(error ? error.message : fn === 'test_deposit' ? 'TEST deposit credited.' : 'TEST withdrawal request sent for admin review.')
    if (!error) { setKey(crypto.randomUUID()); setAmt('') }
    setBusy(false); load()
  }
  const badge = <span style={{ background: '#3a2c0c', color: '#ffd98a', borderRadius: 6, padding: '1px 6px', fontSize: 11 }}>TEST MODE</span>
  return <>
    <div className="card"><p className="mut">TEST MODE: simulated wallet. Test points are not money and cannot be cashed out. No bank, UPI or card details are ever requested.</p>
      <div className="mut">Test-point balance</div><div className="big">{bal.toLocaleString()}</div>
      <input type="number" min={1} placeholder="Test amount" value={amt} onChange={e => setAmt(e.target.value)} />
      <div className="row"><button disabled={busy} onClick={() => act('test_deposit')}>Deposit (test)</button><button className="ghost" disabled={busy} onClick={() => act('request_withdrawal')}>Withdraw (test)</button></div>
      <p className={msg.startsWith('TEST') ? 'ok' : 'err'}>{msg}</p></div>
    <div className="card"><h3>Wallet requests</h3><table><tbody>{rows.map(r => <tr key={r.id}><td>{r.kind} {badge}</td><td>{r.amount}</td><td>{r.status}</td><td className="mut">{new Date(r.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>
    <div className="card"><h3>All transactions</h3><table><tbody>{tx.map(t => <tr key={t.id}><td>{t.kind} {badge}</td><td>{t.amount > 0 ? '+' : ''}{t.amount}</td><td>completed</td><td className="mut">{new Date(t.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>
  </>
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null), [ready, setReady] = useState(false)
  const [me, setMe] = useState<Row | null>(null), [bal, setBal] = useState(0), [stats, setStats] = useState({ played: 0, won: 0 }), [tab, setTab] = useState('home'), [view, setView] = useState<'landing' | 'in' | 'up'>('landing')
  useEffect(() => {
    if (!configured) return
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true) })
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => data.subscription.unsubscribe()
  }, [])
  const refresh = useCallback(async () => {
    const [p, w, a, b] = await Promise.all([
      supabase.from('profiles').select('*').maybeSingle(),
      supabase.from('virtual_wallets').select('balance').maybeSingle(),
      supabase.from('game_predictions').select('*', { count: 'exact', head: true }),
      supabase.from('game_predictions').select('*', { count: 'exact', head: true }).gt('payout', 0)])
    setMe(p.data); setBal(w.data?.balance ?? 0); setStats({ played: a.count ?? 0, won: b.count ?? 0 })
  }, [])
  useEffect(() => { if (session) refresh(); else setMe(null) }, [session, refresh])

  if (!configured) return <div className="wrap"><div className="logo">WIN BRAZZER</div><div className="card"><h3>Setup required</h3><p>Copy <code>.env.example</code> to <code>.env</code> and set your Supabase URL and anon key, then restart. See README.</p></div></div>
  if (location.hash.startsWith('#/admin')) return <Admin />
  if (!ready) return <div className="wrap"><div className="logo">Loading…</div></div>
  if (!session) return view === 'landing' ? <Landing onLogin={() => setView('in')} onRegister={() => setView('up')} /> : <Auth initial={view} onBack={() => setView('landing')} />
  if (!me) return <div className="wrap"><div className="logo">Loading…</div></div>
  const tabs: [string, string][] = [['home', 'Home'], ['games', 'Games'], ['rewards', 'Rewards'], ['invite', 'Invite'], ['account', 'Account']]
  const game = tab === 'number' || tab === 'color'
  return (
    <div className="wrap">
      <div className="row"><div className="logo">WIN BRAZZER</div><span className="mut">{bal.toLocaleString()} pts</span></div>
      {me.status === 'suspended' && <p className="err">Your account is suspended. Contact support.</p>}
      {tab === 'home' && <Home me={me} bal={bal} stats={stats} refresh={refresh} go={setTab} />}
      {tab === 'games' && <div className="card"><h3>Choose a game</h3><div className="row"><button onClick={() => setTab('number')}>Number 0-9</button><button onClick={() => setTab('color')}>Color</button></div></div>}
      {game && <Game key={tab} kind={tab as 'number' | 'color'} me={me} refresh={refresh} />}
      {tab === 'rewards' && <Rewards refresh={refresh} />}
      {tab === 'wallet' && <Wallet bal={bal} refresh={refresh} />}
      {tab === 'invite' && <Invite me={me} />}
      {tab === 'account' && <Account me={me} reload={refresh} go={setTab} />}
      {tab === 'notifications' && <Notifications />}
      {tab === 'history' && <GameHistory />}
      {tab === 'txns' && <Txns />}
      {(tab === 'help' || tab === 'terms' || tab === 'privacy') && <StaticPage k={tab} />}
      <nav>{tabs.map(([k, t]) => <button key={k} className={tab === k || (k === 'games' && game) || (k === 'account' && ['notifications', 'history', 'txns', 'help', 'terms', 'privacy'].includes(tab)) ? 'on' : ''} onClick={() => setTab(k)}>{t}</button>)}</nav>
    </div>
  )
}
