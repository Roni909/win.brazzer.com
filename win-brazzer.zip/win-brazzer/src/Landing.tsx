export default function Landing({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) {
  const feats: [string, string][] = [['🔢', 'Number prediction: pick 0-9 each round'], ['🎨', 'Color prediction: green, red or violet'], ['🎁', 'Daily rewards and a welcome bonus'], ['🤝', 'Invite friends and both earn free points']]
  return (
    <div className="wrap">
      <div className="logo" style={{ fontSize: 34 }}>WIN BRAZZER</div>
      <div className="card"><h2>Free prediction games</h2>
        <p className="mut">Play with demo points, climb your history and invite friends. No deposits, no withdrawals, no cash value.</p>
        <div className="row"><button onClick={onRegister}>Create account</button><button className="ghost" onClick={onLogin}>Login</button></div></div>
      {feats.map(([i, t]) => <div className="card" key={t}>{i} {t}</div>)}
      <div className="card"><h3>How it works</h3><p className="mut">1. Register and get a welcome bonus. 2. Pick a number or color before the timer ends. 3. The server picks a random result, never influenced by players. Points are entertainment only.</p></div>
      <p className="mut" style={{ textAlign: 'center' }}><a href="#/admin" onClick={() => setTimeout(() => location.reload(), 0)}>Admin</a></p>
    </div>
  )
}
