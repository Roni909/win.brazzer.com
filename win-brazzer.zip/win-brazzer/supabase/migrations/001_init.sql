-- WIN BRAZZER: demo-points only. No deposits, withdrawals, or cash value.
create extension if not exists pgcrypto;

-- ===== TABLES =====
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  display_name text check (char_length(display_name) <= 40),
  user_code text unique not null default upper(substr(md5(random()::text),1,8)),
  status text not null default 'active' check (status in ('active','suspended')),
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);
create table referral_codes (
  user_id uuid primary key references profiles on delete cascade,
  code text unique not null default upper(substr(md5(random()::text),1,8))
);
create table referral_events (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references profiles,
  referred_id uuid not null unique references profiles,   -- one reward per new account
  reward int not null default 200,
  created_at timestamptz not null default now(),
  check (referrer_id <> referred_id)
);
create table virtual_wallets (
  user_id uuid primary key references profiles on delete cascade,
  balance int not null default 0 check (balance >= 0),
  updated_at timestamptz not null default now()
);
create table virtual_point_transactions (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles,
  amount int not null check (amount <> 0),
  kind text not null,
  idem_key text unique not null,                          -- blocks duplicate transactions
  created_at timestamptz not null default now()
);
create index on virtual_point_transactions (user_id, created_at desc);
create table game_rounds (
  id uuid primary key default gen_random_uuid(),
  game text not null check (game in ('number','color')),
  period text unique not null,
  ends_at timestamptz not null,
  status text not null default 'open' check (status in ('open','settled')),
  result smallint,
  created_at timestamptz not null default now()
);
create index on game_rounds (game, status, ends_at);
create table game_predictions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles,
  round_id uuid not null references game_rounds,
  choice smallint not null,
  points int not null check (points between 10 and 500),
  payout int,
  created_at timestamptz not null default now(),
  unique (user_id, round_id)                              -- no duplicate submissions
);
create index on game_predictions (user_id, created_at desc);
create table game_results (
  round_id uuid primary key references game_rounds,
  result smallint not null,
  settled_at timestamptz not null default now()
);
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles,                        -- null = announcement for all
  title text not null, body text,
  created_at timestamptz not null default now()
);
create table admin_audit_logs (
  id bigint generated always as identity primary key,
  admin_id uuid not null references profiles,
  action text not null, target uuid, detail jsonb,
  created_at timestamptz not null default now()
);

-- ===== IMMUTABLE LEDGER / RESULTS =====
create function forbid_change() returns trigger language plpgsql as
$$ begin raise exception 'immutable table'; end $$;
create trigger ledger_immutable before update or delete on virtual_point_transactions
  for each row execute function forbid_change();
create trigger results_immutable before update or delete on game_results
  for each row execute function forbid_change();
create trigger audit_immutable before update or delete on admin_audit_logs
  for each row execute function forbid_change();

-- ===== INTERNAL HELPERS (not callable by clients) =====
create function is_admin() returns boolean language sql security definer stable
set search_path = public as $$
  select exists(select 1 from profiles where id = auth.uid() and role='admin' and status='active') $$;

create function ledger_add(u uuid, amt int, k text, idem text) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  insert into virtual_point_transactions(user_id, amount, kind, idem_key)
    values (u, amt, k, idem) on conflict (idem_key) do nothing;
  if not found then return false; end if;                 -- duplicate: no-op
  update virtual_wallets set balance = balance + amt, updated_at = now() where user_id = u;
  return true;                                            -- CHECK(balance>=0) aborts overdraft
end $$;

-- ===== SIGNUP: profile, wallet, referral code, welcome bonus, referral reward =====
create function handle_new_user() returns trigger language plpgsql security definer
set search_path = public as $$
declare ref text := new.raw_user_meta_data->>'ref'; referrer uuid;
begin
  insert into profiles(id, display_name) values (new.id, split_part(new.email,'@',1));
  insert into virtual_wallets(user_id) values (new.id);
  insert into referral_codes(user_id) values (new.id);
  perform ledger_add(new.id, 1000, 'welcome_bonus', 'welcome:'||new.id);
  if ref is not null then
    select user_id into referrer from referral_codes where code = upper(ref);
    if referrer is not null and referrer <> new.id then
      insert into referral_events(referrer_id, referred_id) values (referrer, new.id)
        on conflict (referred_id) do nothing;
      if found then
        perform ledger_add(referrer, 200, 'referral_reward', 'ref:'||new.id);
        perform ledger_add(new.id, 200, 'referral_bonus', 'refbonus:'||new.id);
      end if;
    end if;
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- ===== CLIENT RPCs =====
create function claim_daily_reward() returns boolean language plpgsql security definer
set search_path = public as $$
begin
  if not exists (select 1 from profiles where id=auth.uid() and status='active') then
    raise exception 'account not active'; end if;
  return ledger_add(auth.uid(), 100, 'daily_reward', 'daily:'||auth.uid()||':'||current_date);
end $$;

create function place_prediction(p_round uuid, p_choice int, p_points int) returns uuid
language plpgsql security definer set search_path = public as $$
declare r game_rounds; pid uuid;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from profiles where id=auth.uid() and status='active') then
    raise exception 'account not active'; end if;
  select * into r from game_rounds where id = p_round;
  if r.id is null or r.status <> 'open' or now() >= r.ends_at then raise exception 'round closed'; end if;
  if p_choice < 0 or p_choice > (case r.game when 'number' then 9 else 2 end) then
    raise exception 'invalid choice'; end if;
  insert into game_predictions(user_id, round_id, choice, points)
    values (auth.uid(), p_round, p_choice, p_points) returning id into pid;  -- unique violation = duplicate
  perform ledger_add(auth.uid(), -p_points, 'game_entry', 'bet:'||pid);
  return pid;
end $$;

-- ===== ROUND ENGINE (server only; call from pg_cron every minute) =====
-- Result uses random() and never reads predictions, so it cannot depend on points chosen.
-- Rules: number exact match = 9x entry; color green/red = 1.9x, violet = 4x. Color odds: 45/45/10.
create function settle_round(rid uuid) returns void language plpgsql security definer
set search_path = public as $$
declare r game_rounds; v int; x float := random(); p record; mult numeric;
begin
  select * into r from game_rounds where id = rid for update;
  if r.id is null or r.status <> 'open' or now() < r.ends_at then return; end if;
  v := case r.game when 'number' then floor(random()*10)::int
                   else case when x < .45 then 0 when x < .90 then 1 else 2 end end;
  mult := case when r.game='number' then 9 when v=2 then 4 else 1.9 end;
  update game_rounds set status='settled', result=v where id=rid;
  insert into game_results(round_id, result) values (rid, v);
  for p in select * from game_predictions where round_id=rid loop
    if p.choice = v then
      update game_predictions set payout = floor(p.points*mult) where id=p.id;
      perform ledger_add(p.user_id, floor(p.points*mult)::int, 'game_win', 'win:'||p.id);
    else
      update game_predictions set payout = 0 where id=p.id;
    end if;
  end loop;
end $$;

create function tick() returns void language plpgsql security definer
set search_path = public as $$
declare g text; rid uuid;
begin
  for rid in select id from game_rounds where status='open' and ends_at <= now() loop
    perform settle_round(rid);
  end loop;
  foreach g in array array['number','color'] loop
    if not exists (select 1 from game_rounds where game=g and status='open') then
      insert into game_rounds(game, period, ends_at)
      values (g, to_char(now(),'YYYYMMDDHH24MISS')||left(g,1), now() + interval '60 seconds')
      on conflict (period) do nothing;
    end if;
  end loop;
end $$;

-- ===== ADMIN RPCs (authorization enforced inside the database) =====
create function admin_set_status(target uuid, new_status text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  if new_status not in ('active','suspended') then raise exception 'bad status'; end if;
  update profiles set status = new_status where id = target;
  insert into admin_audit_logs(admin_id, action, target, detail)
    values (auth.uid(), 'set_status', target, jsonb_build_object('status', new_status));
end $$;

create function admin_grant_points(target uuid, amt int, note text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  perform ledger_add(target, amt, 'admin_promo', 'admin:'||gen_random_uuid());
  insert into admin_audit_logs(admin_id, action, target, detail)
    values (auth.uid(), 'grant_points', target, jsonb_build_object('amount', amt, 'note', note));
end $$;

-- ===== LOCK DOWN FUNCTIONS =====
revoke all on function ledger_add, settle_round, tick, handle_new_user, forbid_change from public, anon, authenticated;
revoke all on function claim_daily_reward, place_prediction, admin_set_status, admin_grant_points from public, anon;
grant execute on function claim_daily_reward, place_prediction, admin_set_status, admin_grant_points, is_admin to authenticated;

-- ===== ROW LEVEL SECURITY =====
alter table profiles enable row level security;
alter table referral_codes enable row level security;
alter table referral_events enable row level security;
alter table virtual_wallets enable row level security;
alter table virtual_point_transactions enable row level security;
alter table game_rounds enable row level security;
alter table game_predictions enable row level security;
alter table game_results enable row level security;
alter table notifications enable row level security;
alter table admin_audit_logs enable row level security;

-- Clients get read-only access to their own data; all writes go through RPCs above.
revoke insert, update, delete on all tables in schema public from anon, authenticated;
grant update (display_name) on profiles to authenticated;

create policy p_own   on profiles for select to authenticated using (id = auth.uid() or is_admin());
create policy p_upd   on profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy rc_own  on referral_codes for select to authenticated using (user_id = auth.uid() or is_admin());
create policy re_own  on referral_events for select to authenticated using (referrer_id = auth.uid() or referred_id = auth.uid() or is_admin());
create policy w_own   on virtual_wallets for select to authenticated using (user_id = auth.uid() or is_admin());
create policy t_own   on virtual_point_transactions for select to authenticated using (user_id = auth.uid() or is_admin());
create policy gr_all  on game_rounds for select to authenticated using (true);
create policy gres_all on game_results for select to authenticated using (true);
create policy gp_own  on game_predictions for select to authenticated using (user_id = auth.uid() or is_admin());
create policy n_own   on notifications for select to authenticated using (user_id = auth.uid() or user_id is null or is_admin());
create policy a_admin on admin_audit_logs for select to authenticated using (is_admin());
