-- FAIR RESULTS (free-play, test points only).
-- Results are drawn from a secret random seed created BEFORE bets are placed.
-- They never read game_predictions, so bet amounts, numbers and colours cannot influence them.
-- Players can verify every finished round: sha256(seed) = published seed_hash.

alter table game_rounds  add column seed_hash text;            -- public commitment, set when round opens
alter table game_results add column seed_hex text;             -- revealed only after the round is settled

create table round_seeds (                                       -- secret until settled; no client access at all
  round_id uuid primary key references game_rounds on delete cascade,
  seed bytea not null
);
alter table round_seeds enable row level security;
revoke all on round_seeds from anon, authenticated;

create table result_audit (                                      -- one immutable row per generated result
  id bigint generated always as identity primary key,
  round_id uuid not null unique references game_rounds,          -- unique: a result can only be generated once
  game text not null,
  result smallint not null,
  seed_hash text,
  method text not null default 'sha256(seed||result) mod range',
  generated_at timestamptz not null default now()
);
create trigger result_audit_immutable before update or delete on result_audit
  for each row execute function forbid_change();
alter table result_audit enable row level security;
revoke insert, update, delete on result_audit from anon, authenticated;
create policy ra_admin on result_audit for select to authenticated using (is_admin());

-- Open rounds with a committed seed.
create or replace function tick() returns void language plpgsql security definer
set search_path = public, extensions as $$
declare g record; rid uuid; s bytea;
begin
  for rid in select id from game_rounds where status='open' and ends_at <= now() loop
    perform settle_round(rid);
  end loop;
  for g in select * from game_settings where enabled loop
    if not exists (select 1 from game_rounds where game = g.game and status = 'open') then
      s := gen_random_bytes(32);
      rid := null;
      insert into game_rounds(game, period, ends_at, seed_hash)
        values (g.game, to_char(now(),'YYYYMMDDHH24MISS')||left(g.game,1),
                now() + make_interval(secs => g.round_seconds), encode(digest(s,'sha256'),'hex'))
        on conflict (period) do nothing returning id into rid;
      if rid is not null then insert into round_seeds(round_id, seed) values (rid, s); end if;
    end if;
  end loop;
end $$;

-- Settle: row-locked, open-only, closes entries, stores result + audit row. Duplicate generation is impossible.
create or replace function settle_round(rid uuid) returns void language plpgsql security definer
set search_path = public, extensions as $$
declare r game_rounds; s bytea; d bytea; n bigint; v int; mult numeric; p record;
begin
  select * into r from game_rounds where id = rid for update;
  if r.id is null or r.status <> 'open' or now() < r.ends_at then return; end if;
  select seed into s from round_seeds where round_id = rid;
  if s is null then s := gen_random_bytes(32); end if;           -- rounds opened before this migration
  d := digest(s || 'result'::bytea, 'sha256');
  n := get_byte(d,0)::bigint*16777216 + get_byte(d,1)*65536 + get_byte(d,2)*256 + get_byte(d,3);
  v := case r.game when 'number' then (n % 10)::int
                   else case when n % 100 < 45 then 0 when n % 100 < 90 then 1 else 2 end end;
  mult := case when r.game = 'number' then 9 when v = 2 then 4 else 1.9 end;
  update game_rounds set status = 'settled', result = v where id = rid;   -- entries are now locked
  insert into game_results(round_id, result, seed_hex) values (rid, v, encode(s,'hex'));
  insert into result_audit(round_id, game, result, seed_hash) values (rid, r.game, v, r.seed_hash);
  for p in select * from game_predictions where round_id = rid loop
    if p.choice = v then
      update game_predictions set payout = floor(p.points*mult) where id = p.id;
      perform ledger_add(p.user_id, floor(p.points*mult)::int, 'game_win', 'win:'||p.id);
    else
      update game_predictions set payout = 0 where id = p.id;
    end if;
  end loop;
  delete from round_seeds where round_id = rid;
end $$;

-- Admin statistics: READ ONLY, never used by tick() or settle_round().
create function admin_round_stats() returns json language plpgsql security definer stable
set search_path = public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  return coalesce((select json_agg(x) from (
    select r.game, r.period, p.choice, sum(p.points)::int as points, count(distinct p.user_id)::int as players
    from game_rounds r join game_predictions p on p.round_id = r.id
    where r.status = 'open' group by r.game, r.period, p.choice order by r.game, p.choice) x), '[]'::json);
end $$;

revoke all on function admin_round_stats from public, anon;
grant execute on function admin_round_stats to authenticated;
revoke all on function tick, settle_round from public, anon, authenticated;
