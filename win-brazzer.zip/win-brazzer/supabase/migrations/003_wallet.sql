-- SIMULATED wallet (TEST MODE). Test points are not money and cannot be cashed out.
-- No payment gateway, bank, or UPI data is used or stored anywhere.
create table wallet_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles,
  kind text not null check (kind in ('deposit','withdrawal')),
  amount int not null check (amount between 1 and 100000),
  status text not null check (status in ('completed','pending','approved','rejected')),
  mode text not null default 'TEST MODE' check (mode = 'TEST MODE'),
  idem_key text not null,
  reviewed_by uuid references profiles,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, idem_key)                       -- duplicate request = same row, no second credit
);
create index on wallet_requests (user_id, created_at desc);
create index on wallet_requests (status, created_at desc);
create unique index one_pending_withdrawal on wallet_requests (user_id)
  where kind = 'withdrawal' and status = 'pending';
alter table wallet_requests enable row level security;
revoke insert, update, delete on wallet_requests from anon, authenticated;
create policy wr_own on wallet_requests for select to authenticated
  using (user_id = auth.uid() or is_admin());

-- Test deposit: validated and credited on the server only (max 10,000 per request, 50,000 per day).
create function test_deposit(p_amount int, p_key text) returns uuid
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); rid uuid;
begin
  if uid is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from profiles where id = uid and status = 'active') then raise exception 'account not active'; end if;
  if p_amount is null or p_amount < 1 or p_amount > 10000 then raise exception 'amount must be 1-10000 test points'; end if;
  if p_key is null or char_length(p_key) < 8 then raise exception 'missing request key'; end if;
  perform pg_advisory_xact_lock(hashtext(uid::text));          -- serialize this user's requests
  select id into rid from wallet_requests where user_id = uid and idem_key = p_key;
  if rid is not null then return rid; end if;
  if coalesce((select sum(amount) from wallet_requests
               where user_id = uid and kind = 'deposit' and created_at > now() - interval '1 day'), 0) + p_amount > 50000 then
    raise exception 'daily test deposit limit reached'; end if;
  insert into wallet_requests(user_id, kind, amount, status, idem_key)
    values (uid, 'deposit', p_amount, 'completed', p_key) returning id into rid;
  perform ledger_add(uid, p_amount, 'test_deposit', 'tdep:' || rid);
  return rid;
end $$;

-- Test withdrawal request: points are held immediately (cannot be spent twice); admin approves or rejects.
create function request_withdrawal(p_amount int, p_key text) returns uuid
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); rid uuid; bal int;
begin
  if uid is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from profiles where id = uid and status = 'active') then raise exception 'account not active'; end if;
  if p_amount is null or p_amount < 1 or p_amount > 100000 then raise exception 'amount must be 1-100000 test points'; end if;
  if p_key is null or char_length(p_key) < 8 then raise exception 'missing request key'; end if;
  perform pg_advisory_xact_lock(hashtext(uid::text));
  select id into rid from wallet_requests where user_id = uid and idem_key = p_key;
  if rid is not null then return rid; end if;
  if exists (select 1 from wallet_requests where user_id = uid and kind = 'withdrawal' and status = 'pending') then
    raise exception 'you already have a pending withdrawal request'; end if;
  select balance into bal from virtual_wallets where user_id = uid for update;
  if p_amount > bal then raise exception 'not enough test points'; end if;
  insert into wallet_requests(user_id, kind, amount, status, idem_key)
    values (uid, 'withdrawal', p_amount, 'pending', p_key) returning id into rid;
  perform ledger_add(uid, -p_amount, 'withdrawal_hold', 'wdhold:' || rid);
  return rid;
end $$;

create function admin_review_withdrawal(p_id uuid, p_approve boolean) returns void
language plpgsql security definer set search_path = public as $$
declare r wallet_requests;
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  select * into r from wallet_requests where id = p_id and kind = 'withdrawal' for update;
  if r.id is null or r.status <> 'pending' then raise exception 'request is not pending'; end if;
  if r.user_id = auth.uid() then raise exception 'you cannot review your own request'; end if;
  update wallet_requests set status = case when p_approve then 'approved' else 'rejected' end,
         reviewed_by = auth.uid(), reviewed_at = now() where id = p_id;
  if not p_approve then perform ledger_add(r.user_id, r.amount, 'withdrawal_refund', 'wdref:' || p_id); end if;
  insert into admin_audit_logs(admin_id, action, target, detail)
    values (auth.uid(), case when p_approve then 'approve_withdrawal' else 'reject_withdrawal' end, r.user_id,
            jsonb_build_object('request', p_id, 'amount', r.amount, 'mode', 'TEST MODE'));
end $$;

revoke all on function test_deposit, request_withdrawal, admin_review_withdrawal from public, anon;
grant execute on function test_deposit, request_withdrawal, admin_review_withdrawal to authenticated;
