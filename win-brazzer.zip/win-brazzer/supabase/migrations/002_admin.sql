-- Game schedule settings, announcements, stats (all admin-enforced in the database)
create table game_settings (
  game text primary key check (game in ('number','color')),
  round_seconds int not null default 60 check (round_seconds between 15 and 3600),
  enabled boolean not null default true
);
insert into game_settings(game) values ('number'),('color');
alter table game_settings enable row level security;
revoke insert, update, delete on game_settings from anon, authenticated;
create policy gs_admin on game_settings for select to authenticated using (is_admin());

create or replace function tick() returns void language plpgsql security definer
set search_path = public as $$
declare g record; rid uuid;
begin
  for rid in select id from game_rounds where status='open' and ends_at <= now() loop
    perform settle_round(rid);
  end loop;
  for g in select * from game_settings where enabled loop
    if not exists (select 1 from game_rounds where game=g.game and status='open') then
      insert into game_rounds(game, period, ends_at)
      values (g.game, to_char(now(),'YYYYMMDDHH24MISS')||left(g.game,1), now() + make_interval(secs => g.round_seconds))
      on conflict (period) do nothing;
    end if;
  end loop;
end $$;

create function admin_post_announcement(p_title text, p_body text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  if char_length(coalesce(p_title,'')) = 0 or char_length(p_title) > 100 or char_length(coalesce(p_body,'')) > 500 then
    raise exception 'invalid announcement'; end if;
  insert into notifications(title, body) values (p_title, p_body);
  insert into admin_audit_logs(admin_id, action, detail) values (auth.uid(), 'announcement', jsonb_build_object('title', p_title));
end $$;

create function admin_set_game_settings(p_game text, p_seconds int, p_enabled boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  update game_settings set round_seconds = p_seconds, enabled = p_enabled where game = p_game;
  insert into admin_audit_logs(admin_id, action, detail)
    values (auth.uid(), 'game_settings', jsonb_build_object('game', p_game, 'seconds', p_seconds, 'enabled', p_enabled));
end $$;

create function admin_stats() returns json language plpgsql security definer stable
set search_path = public as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  return json_build_object(
    'users', (select count(*) from profiles),
    'suspended', (select count(*) from profiles where status='suspended'),
    'rounds', (select count(*) from game_rounds where status='settled'),
    'predictions', (select count(*) from game_predictions),
    'referrals', (select count(*) from referral_events),
    'points_in_circulation', (select coalesce(sum(balance),0) from virtual_wallets));
end $$;

revoke all on function admin_post_announcement, admin_set_game_settings, admin_stats from public, anon;
grant execute on function admin_post_announcement, admin_set_game_settings, admin_stats to authenticated;
